package SimpleCalculator;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.MessageFormat;

public class Calculator extends JFrame {
    private JTextField tfNumber1;
    private JComboBox cbOperations;
    private JTextField tfNumber2;
    private JTextField tfResult;
    private JButton btnCompute;
    private JPanel pMain;

    Calculator() {
        pMain.setName("Simple Calculator");
        btnCompute.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a = Integer.parseInt(tfNumber1.getText());
                int b = Integer.parseInt(tfNumber2.getText());
                int res = 0;

                if (cbOperations.getSelectedItem() == "+") {
                    res = a + b;
                } else if (cbOperations.getSelectedItem() == "-") {
                    res = a - b;
                } else if (cbOperations.getSelectedItem() == "*") {
                    res = a * b;
                } else if (cbOperations.getSelectedItem() == "/") {
                    res = a / b;
                }
                tfResult.setText(String.valueOf(res));
            }
        });
    }

    public static void main(String[] args) {
        Calculator app = new Calculator();
        app.setContentPane(app.pMain);
        app.setSize(400, 300);
        app.setDefaultCloseOperation(EXIT_ON_CLOSE);
        app.setVisible(true);
    }
}
