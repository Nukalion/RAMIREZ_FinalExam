package FoodOrderingSystem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoodOrder extends JFrame {

    private JPanel pMain;
    private JCheckBox pizzaCheckBox, burgerCheckBox, friesCheckBox, softDrinksCheckBox, teaCheckBox, sundaeCheckBox;
    private JRadioButton a10OffRadioButton, a5OffRadioButton, noneRadioButton, a15OffRadioButton;
    private JRadioButton[] discount = {a10OffRadioButton, a5OffRadioButton, noneRadioButton, a15OffRadioButton};
    private JButton orderButton;

    FoodOrder() {
        orderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                float price = 0;

                if (pizzaCheckBox.isSelected()) {
                    price += 100;
                }
                if (burgerCheckBox.isSelected()) {
                    price += 80;
                }
                if (friesCheckBox.isSelected()) {
                    price += 65;
                }
                if (softDrinksCheckBox.isSelected()) {
                    price += 55;
                }
                if (teaCheckBox.isSelected()) {
                    price += 50;
                }
                if (sundaeCheckBox.isSelected()) {
                    price += 40;
                }

                if (a10OffRadioButton.isSelected()) {
                    price = (float) (price - (price*.10));
                }
                if (a5OffRadioButton.isSelected()) {
                    price = (float) (price - (price*.05));
                }
                if (a15OffRadioButton.isSelected()) {
                    price = (float) (price - (price*.15));
                }

                JOptionPane.showMessageDialog(null, "The total price is Php " + String.format("%.2f", price));

            }
        });
    }

    public static void main(String[] args) {
        FoodOrder app = new FoodOrder();
        app.setContentPane(app.pMain);
        app.setSize(400, 300);
        app.setDefaultCloseOperation(EXIT_ON_CLOSE);
        app.setVisible(true);
    }
}
